## simulate phenotype data for testing
## parameters
set.seed(11)
MAF <- 0.3
rho <- 0.5
K <- 3
n <- 500
r <- 5/100
n1 <- (1-r)*n

## simulate genotype
g1 <- sample(c(1,0),n,replace=TRUE,prob=c(MAF,1-MAF))
g2 <- sample(c(1,0),n,replace=TRUE,prob=c(MAF,1-MAF))
g <- g1+g2

beta <- sqrt(0.05/(2*(1-0.05)*MAF*(1-MAF)))
rho0 <- c(1, rep(rho, K))
sigma <- matrix(c(rep(rho0, K-1), 1), K, K)
theta <- matrix(rep(beta*g, K),n,K)

## simulate phenotype
Y <- matrix(0,n,K)
for(i in 1:n){
  Y[i,]=mvtnorm::rmvnorm(1,mean=theta[i,], sigma)
}
Y[-(1:n1), 3] <- NA #missing values should be at the end

simulated_phenotype <- Y
usethis::use_data(simulated_phenotype, overwrite = TRUE)
