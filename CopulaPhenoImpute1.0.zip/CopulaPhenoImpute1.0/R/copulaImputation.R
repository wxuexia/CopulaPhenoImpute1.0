# Phenotype imputation using Gaussian copula

# main function -----------------------------------------------------------
#' @title copulaImputation
#'
#' @description main function for performing phenotype imputation
#'
#'
#'
#' @param pheno_matrix matrix of phenotypes to be used for imputation
#' @param lossfunction character string indicating which loss function to use "square", "0-1", or "quantile"
#' @param impute_col integer specifying which column of pheno_matrix requires imputation (contains NA)
#'
#' @return phenotype matrix with missing values replaced with imputed values
#' @export
#'
#' @import MASS
#' @importFrom mvtnorm rmvnorm
#' @importFrom stats dnorm integrate optimize pnorm qnorm sd uniroot
#' @examples
#'
#' copulaImputation(simulated_phenotype, lossfunction = "square", impute_col = 3)
#'

copulaImputation <- function(pheno_matrix, lossfunction = "square",
                             impute_col = ncol(pheno_matrix)) {

  column_names <- colnames(pheno_matrix)
  # checks
  if(!lossfunction %in% c("square", "0-1", "quantile")){
    stop("Select a valid loss function: square, 0-1, or quantile.")
  }

  pheno_matrix <- as.data.frame(pheno_matrix)

  ### parameter setup #######
  K <- ncol(pheno_matrix)
  N <- nrow(pheno_matrix)

  if(K < 2){
    stop("Not enough phenotypes to perform imputation.")
  }

  n2 <- length(which(is.na(pheno_matrix[,impute_col]))) # number of obs with missing values
  n1 <- N-n2 # number of complete obs

  ### divide pheno_matrix into two parts #######
  y1 <- pheno_matrix[1:n1,] # all complete observations
  y2 <- pheno_matrix[-(1:n1),]
  y_ref <- as.matrix(y2[,1:(K-1)]) # y values used for imputation
  y_nonimputed <- pheno_matrix[1:n1,K] # the non imputed trait values for the trait with missing values

  ### estimation based on first part #######
  y_1mean <- colMeans(y1)
  y_1sd <- apply(y1, 2, sd)
  Q <- matrix(0, n1, K)

  for(i in 1:K){
    Q[,i] <- qnorm(pnorm(y1[,i], y_1mean[i], y_1sd[i]))
  }

  if(length(which(is.infinite(Q)))!=0){

    Q <- Q[-which(is.infinite(Q[,K])), ]
    }

  R <- 1 / n1 * t(Q) %*% Q


  if(lossfunction=="square"){
    pheno_imputed <- squareLossFunction(y_ref, n2, K, R, y_1mean, y_1sd)

  }else if(lossfunction == "0-1"){
    pheno_imputed <- unifLossFunction(y_ref, y1, n2, K, R, y_1mean, y_1sd)

  }else if(lossfunction == "quantile"){
    pheno_imputed <- quantileLossFunction(y_ref, y1, n2, K, R, y_1mean, y_1sd)

  }

  # append imputed to dataset
  Y_full <- cbind(pheno_matrix[,1:(K-1)], c(y_nonimputed, pheno_imputed))
  colnames(Y_full) <- column_names

 return(Y_full)
}



# helper functions --------------------------------------------------------
fcopula <- function(u, K, R){
  q0 <- matrix(qnorm(u), 1, K)
  q1 <- matrix(qnorm(u), K, 1)
  t <- q0 %*% (diag(rep(1, length = K)) - solve(R)) %*% q1
  t0 <- 1 / sqrt(det(R)) * exp(0.5 * t)
  return(as.numeric(t0))
}



# loss functions ----------------------------------------------------------
squareLossFunction <- function(y_ref, n2, K, R, y_1mean, y_1sd){
  y_imputed <- rep(0, n2)
  for (j in 1:n2) {
    y <- as.vector(y_ref[j,])
    u <- 1:K
    for (i in 1:(K - 1)) {
      u[i] <- pnorm(y[i], y_1mean[i], y_1sd[i])
    }
    integrand0 <- function(u_K) {
      t <- c()
      for (i in 1:length(u_K)) {
        t[i] <- fcopula(u = c(u[-K], u_K[i]), K = K, R = R) * qnorm(u_K[i], y_1mean[K], y_1sd[K])
      }
      return(t)
    }
    f3 <- tryCatch(integrate(integrand0, lower = 0, upper =1)[[1]],error = function(e) {NA})
    integrand <- function(u_K) {
      t <- c()
      for (i in 1:length(u_K)) {
        t[i] <- fcopula(u = c(u[-K], u_K[i]), K = K, R = R)
      }
      return(t)
    }
    f1 <- tryCatch(integrate(integrand, lower = 0, upper =1)[[1]],error = function(e) {NA})
    result <- f3 / f1
    y_imputed[j] <- result
  }
  return(y_imputed)
}

unifLossFunction <- function(y_ref, y1, n2, K, R, y_1mean, y_1sd){
  y_imputed=1:n2
  for(j in 1:n2){
    y <- y_ref[j, ]
    f0=function(y_K){
      u=1:K
      for(i in 1:(K-1)){
        u[i]=pnorm(y[i],y_1mean[i],y_1sd[i])
      }
      u[3]=pnorm(y_K,y_1mean[3],y_1sd[3])
      fcopula(u, K , R)*dnorm(y_K,y_1mean[3],y_1sd[3])
    }
    result=tryCatch(optimize(f0,c(2*min(y1[,K]),2*max(y1[,K])),tol=0.0001,maximum = TRUE)[[1]], error = function(e) {NA})
    y_imputed[j]=result
  }
  return(y_imputed)
}

quantileLossFunction <- function(y_ref, y1, n2, K, R, y_1mean, y_1sd){
  F_conditional <- function(y) {
    u <- 1:K
    for (i in 1:K) {
      u[i] <- pnorm(y[i], y_1mean[i], y_1sd[i])
    }
    integrand <- function(u_K) {
      t <- c()
      for (i in 1:length(u_K)) {
        t[i] <- fcopula(u = c(u[-K], u_K[i]), K = K, R = R)
      }
      return(t)
    }
    t0 <- u[K]
    f1 <- tryCatch(integrate(integrand, lower = 0, upper = t0)[[1]], error = function(e) {NA})
    f3 <- tryCatch(integrate(integrand, lower = 0, upper = 1)[[1]], error = function(e) {NA})
    result <- f1 / f3
    return(result)
  }
  y_imputed <- 1:n2
  for (j in 1:n2) {
    y <- as.numeric(y_ref[j, ]) #TODO: may need fixing for K = 2
    g <- function(y_K) {
      y <- c(y, y_K)
      F_conditional(y) - 0.5
    }
    y_imputed[j] <- tryCatch(uniroot(g,c(min(y1[,K]),max(y1[,K])),tol = 1e-3)[[1]],
                             error = function(e) {uniroot(g,c(min(y1[,K])-10,max(y1[,K])+10),tol = 1e-6)[[1]]})
  }
  return(y_imputed)
}
