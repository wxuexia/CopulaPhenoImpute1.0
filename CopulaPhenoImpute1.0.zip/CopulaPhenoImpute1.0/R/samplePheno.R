#' @title Example Phenotype Data With Missing Values
#'
#' @description Example phenotype data containing 3 traits simulated from a multivariate distribution
#'
#' @format a matrix with 500 rows and 3 columns, in which the third column contains missing values
"simulated_phenotype"
